This is made using HTML CSS and simple javascript 
# Project_web_page (Deployed Link): https://basanttiwari.github.io/Project_web_page/
